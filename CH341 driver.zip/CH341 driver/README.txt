Use SETUP.EXE to install driver

For windows 8       --> "/CH341 driver/CH341SER-win7/CH341SER/SETUP.EXE"
For windows 8 or 10 --> "/CH341 driver/CH341SERwin8/CH341SER/SETUP.EXE"
